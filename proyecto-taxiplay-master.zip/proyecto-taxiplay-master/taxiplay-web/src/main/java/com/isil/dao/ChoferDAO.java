package com.isil.dao;

import com.isil.model.Chofer;

public interface ChoferDAO extends DAO <Chofer, Integer> {
}
