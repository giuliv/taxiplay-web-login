package com.isil.dao;

import com.isil.model.Vehiculo;

public interface VehiculoDAO extends DAO <Vehiculo, Integer> {
}
